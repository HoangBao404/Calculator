﻿using System;
using System.Globalization;
using System.Text;
using HoangBao_Lab5;

namespace HoangBao_Lab5.ConsoleApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.InputEncoding = Encoding.UTF8;
            Console.OutputEncoding = Encoding.UTF8;

            QuanLyHocVien ql = new QuanLyHocVien();

            int soLuong = NhapSoLuong();

            for (int i = 0; i < soLuong; i++)
            {
                Console.WriteLine(
                    "\n--- Học viên thứ {0} ---", i + 1);

                Console.Write("Mã số: ");
                string maSo = Console.ReadLine();

                Console.Write("Họ tên: ");
                string hoTen = Console.ReadLine();

                Console.Write("Quê quán: ");
                string queQuan = Console.ReadLine();

                double mon1 = NhapDiem("Điểm môn 1: ");
                double mon2 = NhapDiem("Điểm môn 2: ");
                double mon3 = NhapDiem("Điểm môn 3: ");

                ql.Them(new HocVien(
                    maSo, hoTen, queQuan, mon1, mon2, mon3));
            }

            Console.WriteLine(
                "\n=== DANH SÁCH HỌC VIÊN ĐƯỢC HỌC BỔNG ===");

            var ketQua = ql.DanhSachHocBong();

            if (ketQua.Count == 0)
            {
                Console.WriteLine("Không có học viên đủ điều kiện.");
            }
            else
            {
                foreach (HocVien hv in ketQua)
                {
                    Console.WriteLine(
                        "{0} | {1} | {2} | Điểm TB: {3:F2}",
                        hv.MaSo,
                        hv.HoTen,
                        hv.QueQuan,
                        hv.DiemTrungBinh());
                }
            }

            Console.WriteLine("\nNhấn Enter để kết thúc.");
            Console.ReadLine();
        }

        private static int NhapSoLuong()
        {
            while (true)
            {
                Console.Write("Nhập số lượng học viên: ");

                int soLuong;

                if (int.TryParse(Console.ReadLine(), out soLuong)
                    && soLuong >= 0)
                {
                    return soLuong;
                }

                Console.WriteLine("Vui lòng nhập số nguyên không âm.");
            }
        }

        private static double NhapDiem(string thongBao)
        {
            while (true)
            {
                Console.Write(thongBao);

                string input = Console.ReadLine() ?? "";
                input = input.Trim().Replace(',', '.');

                double diem;

                if (double.TryParse(
                    input,
                    NumberStyles.AllowDecimalPoint |
                    NumberStyles.AllowLeadingSign,
                    CultureInfo.InvariantCulture,
                    out diem)
                    && diem >= 0
                    && diem <= 10)
                {
                    return diem;
                }

                Console.WriteLine("Vui lòng nhập điểm từ 0 đến 10.");
            }
        }
    }
}