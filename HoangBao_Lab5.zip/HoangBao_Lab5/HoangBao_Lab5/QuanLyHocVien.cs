﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace HoangBao_Lab5
{
    public class QuanLyHocVien
    {
        private List<HocVien> danhSach = new List<HocVien>();

        public void Them(HocVien hocVien)
        {
            if (hocVien == null)
                throw new ArgumentNullException(nameof(hocVien));

            danhSach.Add(hocVien);
        }

        public List<HocVien> DanhSachHocBong()
        {
            return danhSach
                .Where(hv => hv.DuocHocBong())
                .ToList();
        }
    }
}