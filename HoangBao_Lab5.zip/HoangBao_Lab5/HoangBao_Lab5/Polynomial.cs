﻿using System;
using System.Collections.Generic;

namespace HoangBao_Lab5
{
    public class Polynomial
    {
        private int n;
        private List<int> a;

        public Polynomial(int n, List<int> a)
        {
            if (n < 0 || a == null || a.Count != n + 1)
                throw new ArgumentException("Invalid Data");

            this.n = n;
            this.a = new List<int>(a);
        }

        public double Cal(double x)
        {
            double result = 0;

            for (int i = 0; i <= this.n; i++)
            {
                result += a[i] * Math.Pow(x, i);
            }

            return result;
        }
    }
}