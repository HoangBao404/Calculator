﻿using System;

namespace HoangBao_Lab5
{
    public class HinhChuNhat
    {
        private Diem trenTrai;
        private Diem duoiPhai;

        public HinhChuNhat(Diem trenTrai, Diem duoiPhai)
        {
            if (trenTrai == null || duoiPhai == null)
                throw new ArgumentException("Invalid Rectangle");

            if (trenTrai.X >= duoiPhai.X ||
                trenTrai.Y <= duoiPhai.Y)
            {
                throw new ArgumentException("Invalid Rectangle");
            }

            this.trenTrai = new Diem(trenTrai.X, trenTrai.Y);
            this.duoiPhai = new Diem(duoiPhai.X, duoiPhai.Y);
        }

        public double DienTich()
        {
            double chieuRong = duoiPhai.X - trenTrai.X;
            double chieuCao = trenTrai.Y - duoiPhai.Y;

            return chieuRong * chieuCao;
        }

        public bool GiaoNhau(HinhChuNhat other)
        {
            if (other == null)
                throw new ArgumentNullException(nameof(other));

            // Hai hình nằm tách nhau theo chiều ngang.
            if (duoiPhai.X < other.trenTrai.X ||
                trenTrai.X > other.duoiPhai.X)
            {
                return false;
            }

            // Hai hình nằm tách nhau theo chiều dọc.
            if (duoiPhai.Y > other.trenTrai.Y ||
                trenTrai.Y < other.duoiPhai.Y)
            {
                return false;
            }

            return true;
        }
    }
}