﻿using System;

namespace HoangBao_Lab5
{
    public class HocVien
    {
        public string MaSo { get; private set; }
        public string HoTen { get; private set; }
        public string QueQuan { get; private set; }

        public double Mon1 { get; private set; }
        public double Mon2 { get; private set; }
        public double Mon3 { get; private set; }

        public HocVien(
            string maSo, string hoTen, string queQuan,
            double mon1, double mon2, double mon3)
        {
            if (!DiemHopLe(mon1) ||
                !DiemHopLe(mon2) ||
                !DiemHopLe(mon3))
            {
                throw new ArgumentException("Invalid Score");
            }

            MaSo = maSo;
            HoTen = hoTen;
            QueQuan = queQuan;
            Mon1 = mon1;
            Mon2 = mon2;
            Mon3 = mon3;
        }

        private static bool DiemHopLe(double diem)
        {
            return !double.IsNaN(diem)
                && !double.IsInfinity(diem)
                && diem >= 0
                && diem <= 10;
        }

        public double DiemTrungBinh()
        {
            return (Mon1 + Mon2 + Mon3) / 3.0;
        }

        public bool DuocHocBong()
        {
            return DiemTrungBinh() >= 8
                && Mon1 >= 5
                && Mon2 >= 5
                && Mon3 >= 5;
        }
    }
}