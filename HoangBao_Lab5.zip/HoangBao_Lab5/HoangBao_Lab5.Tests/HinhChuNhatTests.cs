﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using HoangBao_Lab5;

namespace HoangBao_Lab5.Tests
{
    [TestClass]
    public class HinhChuNhatTests
    {
        [TestMethod]
        public void DienTich_HinhChuNhat()
        {
            HinhChuNhat h = new HinhChuNhat(
                new Diem(0, 5),
                new Diem(4, 0));

            Assert.AreEqual(20.0, h.DienTich(), 0.000001);
        }

        [TestMethod]
        public void DienTich_ToaDoAm()
        {
            HinhChuNhat h = new HinhChuNhat(
                new Diem(-5, -1),
                new Diem(-1, -4));

            Assert.AreEqual(12.0, h.DienTich(), 0.000001);
        }

        [TestMethod]
        public void DienTich_ToaDoThapPhan()
        {
            HinhChuNhat h = new HinhChuNhat(
                new Diem(0.5, 3.5),
                new Diem(2.5, 1));

            Assert.AreEqual(5.0, h.DienTich(), 0.000001);
        }

        [TestMethod]
        public void GiaoNhau_GiaoMotPhan()
        {
            HinhChuNhat a = new HinhChuNhat(
                new Diem(0, 4), new Diem(4, 0));

            HinhChuNhat b = new HinhChuNhat(
                new Diem(2, 3), new Diem(6, -1));

            Assert.IsTrue(a.GiaoNhau(b));
            Assert.IsTrue(b.GiaoNhau(a));
        }

        [TestMethod]
        public void GiaoNhau_MotHinhNamTrongHinhKia()
        {
            HinhChuNhat a = new HinhChuNhat(
                new Diem(0, 4), new Diem(4, 0));

            HinhChuNhat b = new HinhChuNhat(
                new Diem(1, 3), new Diem(2, 1));

            Assert.IsTrue(a.GiaoNhau(b));
            Assert.IsTrue(b.GiaoNhau(a));
        }

        [TestMethod]
        public void GiaoNhau_HaiHinhTrungNhau()
        {
            HinhChuNhat a = new HinhChuNhat(
                new Diem(0, 4), new Diem(4, 0));

            HinhChuNhat b = new HinhChuNhat(
                new Diem(0, 4), new Diem(4, 0));

            Assert.IsTrue(a.GiaoNhau(b));
        }

        [TestMethod]
        public void GiaoNhau_TachTheoChieuNgang()
        {
            HinhChuNhat a = new HinhChuNhat(
                new Diem(0, 4), new Diem(4, 0));

            HinhChuNhat b = new HinhChuNhat(
                new Diem(5, 3), new Diem(7, 1));

            Assert.IsFalse(a.GiaoNhau(b));
            Assert.IsFalse(b.GiaoNhau(a));
        }

        [TestMethod]
        public void GiaoNhau_TachTheoChieuDoc()
        {
            HinhChuNhat a = new HinhChuNhat(
                new Diem(0, 4), new Diem(4, 0));

            HinhChuNhat b = new HinhChuNhat(
                new Diem(1, -1), new Diem(3, -3));

            Assert.IsFalse(a.GiaoNhau(b));
            Assert.IsFalse(b.GiaoNhau(a));
        }

        [TestMethod]
        public void GiaoNhau_ChamCanh()
        {
            HinhChuNhat a = new HinhChuNhat(
                new Diem(0, 4), new Diem(4, 0));

            HinhChuNhat b = new HinhChuNhat(
                new Diem(4, 3), new Diem(6, 1));

            Assert.IsTrue(a.GiaoNhau(b));
        }

        [TestMethod]
        public void GiaoNhau_ChamGoc()
        {
            HinhChuNhat a = new HinhChuNhat(
                new Diem(0, 4), new Diem(4, 0));

            HinhChuNhat b = new HinhChuNhat(
                new Diem(4, 0), new Diem(6, -2));

            Assert.IsTrue(a.GiaoNhau(b));
        }

        [TestMethod]
        public void Constructor_ToaDoSai()
        {
            try
            {
                new HinhChuNhat(
                    new Diem(4, 0),
                    new Diem(0, 4));
            }
            catch (ArgumentException ex)
            {
                Assert.AreEqual("Invalid Rectangle", ex.Message);
                return;
            }

            Assert.Fail("Phai nem ngoai le khi toa do sai.");
        }

        [TestMethod]
        public void Constructor_ChieuRongBangKhong()
        {
            try
            {
                new HinhChuNhat(
                    new Diem(2, 4),
                    new Diem(2, 0));
            }
            catch (ArgumentException ex)
            {
                Assert.AreEqual("Invalid Rectangle", ex.Message);
                return;
            }

            Assert.Fail("Phai nem ngoai le khi chieu rong bang 0.");
        }
    }
}