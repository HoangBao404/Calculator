﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using HoangBao_Lab5;

namespace HoangBao_Lab5.Tests
{
    [TestClass]
    public class LuyThuaTests
    {
        [TestMethod]
        public void Power_SoMuDuong()
        {
            double actual = LuyThua.Power(2, 3);

            Assert.AreEqual(8.0, actual, 0.000001);
        }

        [TestMethod]
        public void Power_SoMuBangKhong()
        {
            double actual = LuyThua.Power(5, 0);

            Assert.AreEqual(1.0, actual, 0.000001);
        }

        [TestMethod]
        public void Power_SoMuAm()
        {
            double actual = LuyThua.Power(2, -3);

            Assert.AreEqual(0.125, actual, 0.000001);
        }

        [TestMethod]
        public void Power_CoSoAm_MuLe()
        {
            double actual = LuyThua.Power(-2, 3);

            Assert.AreEqual(-8.0, actual, 0.000001);
        }

        [TestMethod]
        public void Power_CoSoAm_MuChan()
        {
            double actual = LuyThua.Power(-2, 2);

            Assert.AreEqual(4.0, actual, 0.000001);
        }

        [TestMethod]
        public void Power_CoSoBangKhong_MuDuong()
        {
            double actual = LuyThua.Power(0, 3);

            Assert.AreEqual(0.0, actual, 0.000001);
        }

        [TestMethod]
        public void Power_CoSoLaSoThuc()
        {
            double actual = LuyThua.Power(0.5, 2);

            Assert.AreEqual(0.25, actual, 0.000001);
        }

        [TestMethod]
        public void Power_CoSoAm_SoMuAm()
        {
            double actual = LuyThua.Power(-2, -3);

            Assert.AreEqual(-0.125, actual, 0.000001);
        }
    }
}