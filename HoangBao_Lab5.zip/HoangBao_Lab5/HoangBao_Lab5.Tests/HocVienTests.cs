﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using HoangBao_Lab5;

namespace HoangBao_Lab5.Tests
{
    [TestClass]
    public class HocVienTests
    {
        [TestMethod]
        public void DiemTrungBinh_TinhDung()
        {
            HocVien hv = new HocVien(
                "HV01", "Hoàng Bảo", "TP.HCM", 7, 8, 9);

            Assert.AreEqual(8.0, hv.DiemTrungBinh(), 0.000001);
        }

        [TestMethod]
        public void HocBong_TrungBinhBang8()
        {
            HocVien hv = new HocVien(
                "HV01", "Hoàng Bảo", "TP.HCM", 8, 8, 8);

            Assert.IsTrue(hv.DuocHocBong());
        }

        [TestMethod]
        public void HocBong_TrungBinhLonHon8()
        {
            HocVien hv = new HocVien(
                "HV01", "Hoàng Bảo", "TP.HCM", 9, 8, 10);

            Assert.IsTrue(hv.DuocHocBong());
        }

        [TestMethod]
        public void HocBong_TrungBinhDuoi8()
        {
            HocVien hv = new HocVien(
                "HV01", "Hoàng Bảo", "TP.HCM", 7, 8, 8);

            Assert.IsFalse(hv.DuocHocBong());
        }

        [TestMethod]
        public void HocBong_MotMonBang5()
        {
            // Trung bình = 8, không có môn dưới 5.
            HocVien hv = new HocVien(
                "HV01", "Hoàng Bảo", "TP.HCM", 5, 9, 10);

            Assert.IsTrue(hv.DuocHocBong());
        }

        [TestMethod]
        public void HocBong_Mon1Duoi5()
        {
            // Trung bình trên 8 nhưng môn 1 dưới 5.
            HocVien hv = new HocVien(
                "HV01", "Hoàng Bảo", "TP.HCM", 4.5, 10, 10);

            Assert.IsFalse(hv.DuocHocBong());
        }

        [TestMethod]
        public void HocBong_Mon2Duoi5()
        {
            HocVien hv = new HocVien(
                "HV01", "Hoàng Bảo", "TP.HCM", 10, 4.5, 10);

            Assert.IsFalse(hv.DuocHocBong());
        }

        [TestMethod]
        public void HocBong_Mon3Duoi5()
        {
            HocVien hv = new HocVien(
                "HV01", "Hoàng Bảo", "TP.HCM", 10, 10, 4.5);

            Assert.IsFalse(hv.DuocHocBong());
        }

        [TestMethod]
        public void HocBong_KhongLamTronLen8()
        {
            HocVien hv = new HocVien(
                "HV01", "Hoàng Bảo", "TP.HCM", 8, 8, 7.99);

            Assert.IsFalse(hv.DuocHocBong());
        }

        [TestMethod]
        public void Constructor_DiemAm()
        {
            try
            {
                new HocVien(
                    "HV01", "Hoàng Bảo", "TP.HCM", -1, 8, 9);
            }
            catch (ArgumentException ex)
            {
                Assert.AreEqual("Invalid Score", ex.Message);
                return;
            }

            Assert.Fail("Phai nem ngoai le khi diem am.");
        }

        [TestMethod]
        public void Constructor_DiemLonHon10()
        {
            try
            {
                new HocVien(
                    "HV01", "Hoàng Bảo", "TP.HCM", 11, 8, 9);
            }
            catch (ArgumentException ex)
            {
                Assert.AreEqual("Invalid Score", ex.Message);
                return;
            }

            Assert.Fail("Phai nem ngoai le khi diem lon hon 10.");
        }

        [TestMethod]
        public void DanhSachHocBong_LocDungHocVien()
        {
            QuanLyHocVien ql = new QuanLyHocVien();

            HocVien bao = new HocVien(
                "HV01", "Hoàng Bảo", "TP.HCM", 8, 9, 10);

            HocVien thu = new HocVien(
                "HV02", "Trần Thư", "TP.HCM", 7, 7, 8);

            HocVien hong = new HocVien(
                "HV03", "Xuân Hồng", "TP.HCM", 5, 9, 10);

            ql.Them(bao);
            ql.Them(thu);
            ql.Them(hong);

            CollectionAssert.AreEqual(
                new HocVien[] { bao, hong },
                ql.DanhSachHocBong());
        }

        [TestMethod]
        public void DanhSachHocBong_DanhSachRong()
        {
            QuanLyHocVien ql = new QuanLyHocVien();

            Assert.AreEqual(0, ql.DanhSachHocBong().Count);
        }

        [TestMethod]
        public void DanhSachHocBong_KhongAiDuDieuKien()
        {
            QuanLyHocVien ql = new QuanLyHocVien();

            ql.Them(new HocVien(
                "HV01", "Hoàng Bảo", "TP.HCM", 7, 7, 7));

            ql.Them(new HocVien(
                "HV02", "Trần Thư", "TP.HCM", 4.5, 10, 10));

            Assert.AreEqual(0, ql.DanhSachHocBong().Count);
        }
    }
}
