﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using HoangBao_Lab5;

namespace HoangBao_Lab5.Tests
{
    [TestClass]
    public class PolynomialTests
    {
        [TestMethod]
        public void Cal_DaThucBacHai()
        {
            // P(x) = 1 + 2x + 3x².
            // P(2) = 1 + 4 + 12 = 17.
            Polynomial p = new Polynomial(
                2, new List<int> { 1, 2, 3 });

            double actual = p.Cal(2);

            Assert.AreEqual(17.0, actual, 0.000001);
        }

        [TestMethod]
        public void Cal_XBangKhong()
        {
            Polynomial p = new Polynomial(
                2, new List<int> { 4, 2, 3 });

            double actual = p.Cal(0);

            Assert.AreEqual(4.0, actual, 0.000001);
        }

        [TestMethod]
        public void Cal_DaThucBacKhong()
        {
            Polynomial p = new Polynomial(
                0, new List<int> { 7 });

            double actual = p.Cal(3);

            Assert.AreEqual(7.0, actual, 0.000001);
        }

        [TestMethod]
        public void Cal_XAm()
        {
            // P(-2) = 1 - 4 + 12 = 9.
            Polynomial p = new Polynomial(
                2, new List<int> { 1, 2, 3 });

            double actual = p.Cal(-2);

            Assert.AreEqual(9.0, actual, 0.000001);
        }

        [TestMethod]
        public void Cal_XLaSoThuc()
        {
            // P(0.5) = 1 + 1 + 0.75 = 2.75.
            Polynomial p = new Polynomial(
                2, new List<int> { 1, 2, 3 });

            double actual = p.Cal(0.5);

            Assert.AreEqual(2.75, actual, 0.000001);
        }

        [TestMethod]
        public void Constructor_ThieuHeSo()
        {
            try
            {
                new Polynomial(2, new List<int> { 1, 2 });
            }
            catch (ArgumentException ex)
            {
                Assert.AreEqual("Invalid Data", ex.Message);
                return;
            }

            Assert.Fail("Phai nem ArgumentException khi thieu he so.");
        }

        [TestMethod]
        public void Constructor_ThuaHeSo()
        {
            try
            {
                new Polynomial(1, new List<int> { 1, 2, 3 });
            }
            catch (ArgumentException ex)
            {
                Assert.AreEqual("Invalid Data", ex.Message);
                return;
            }

            Assert.Fail("Phai nem ArgumentException khi thua he so.");
        }

        [TestMethod]
        public void Constructor_BacAm()
        {
            try
            {
                new Polynomial(-1, new List<int>());
            }
            catch (ArgumentException ex)
            {
                Assert.AreEqual("Invalid Data", ex.Message);
                return;
            }

            Assert.Fail("Phai nem ArgumentException khi bac am.");
        }
    }
}