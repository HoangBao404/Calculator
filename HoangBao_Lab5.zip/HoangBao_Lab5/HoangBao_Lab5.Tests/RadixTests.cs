﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using HoangBao_Lab5;

namespace HoangBao_Lab5.Tests
{
    [TestClass]
    public class RadixTests
    {
        [TestMethod]
        public void Convert_CoSo2()
        {
            Radix r = new Radix(10);

            Assert.AreEqual("1010", r.ConvertDecimalToAnother(2));
        }

        [TestMethod]
        public void Convert_CoSo8()
        {
            Radix r = new Radix(83);

            Assert.AreEqual("123", r.ConvertDecimalToAnother(8));
        }

        [TestMethod]
        public void Convert_CoSo10()
        {
            Radix r = new Radix(123);

            Assert.AreEqual("123", r.ConvertDecimalToAnother(10));
        }

        [TestMethod]
        public void Convert_CoSo16()
        {
            Radix r = new Radix(255);

            Assert.AreEqual("FF", r.ConvertDecimalToAnother(16));
        }

        [TestMethod]
        public void Convert_CacChuSoTuADenF()
        {
            Assert.AreEqual("A",
                new Radix(10).ConvertDecimalToAnother(16));

            Assert.AreEqual("B",
                new Radix(11).ConvertDecimalToAnother(16));

            Assert.AreEqual("C",
                new Radix(12).ConvertDecimalToAnother(16));

            Assert.AreEqual("D",
                new Radix(13).ConvertDecimalToAnother(16));

            Assert.AreEqual("E",
                new Radix(14).ConvertDecimalToAnother(16));

            Assert.AreEqual("F",
                new Radix(15).ConvertDecimalToAnother(16));
        }

        [TestMethod]
        public void Convert_MacDinhCoSo2()
        {
            Radix r = new Radix(10);

            Assert.AreEqual("1010", r.ConvertDecimalToAnother());
        }

        [TestMethod]
        public void Convert_SoBangMot()
        {
            Radix r = new Radix(1);

            Assert.AreEqual("1", r.ConvertDecimalToAnother(2));
        }

        [TestMethod]
        public void Convert_SoBangKhong()
        {
            Radix r = new Radix(0);

            Assert.AreEqual("0", r.ConvertDecimalToAnother(2));
        }

        [TestMethod]
        public void Constructor_SoAm()
        {
            try
            {
                new Radix(-1);
            }
            catch (ArgumentException ex)
            {
                Assert.AreEqual("Incorrect Value", ex.Message);
                return;
            }

            Assert.Fail("Phai nem ngoai le khi so dau vao am.");
        }

        [TestMethod]
        public void Convert_CoSoNhoHon2()
        {
            Radix r = new Radix(10);

            try
            {
                r.ConvertDecimalToAnother(1);
            }
            catch (ArgumentException ex)
            {
                Assert.AreEqual("Invalid Radix", ex.Message);
                return;
            }

            Assert.Fail("Phai nem ngoai le khi co so nho hon 2.");
        }

        [TestMethod]
        public void Convert_CoSoLonHon16()
        {
            Radix r = new Radix(10);

            try
            {
                r.ConvertDecimalToAnother(17);
            }
            catch (ArgumentException ex)
            {
                Assert.AreEqual("Invalid Radix", ex.Message);
                return;
            }

            Assert.Fail("Phai nem ngoai le khi co so lon hon 16.");
        }
    }
}
